const router = require('express').Router();
let weaver = require('../models/weaver');

router.route('/').get((req, res) => {
    weaver.find()
        .then(weaver => res.json(weaver))
        .catch(err => res.status(400).json('Error: ' + err));
});

router.route('/:id').get((req, res) => {
    weaver.findById(req.params.id)
        .then(weaver => res.json(weaver))
        .catch(err => res.status(400).json('Error: ' + err));
});

router.route('/login').post((req, res) => {
    // alert("here!");
    console.log("here!");
    const email = req.body.email;
    const password = req.body.password;
    weaver.findOne({ email: email, password: password }).then(weaver => {
        // Check if user email exists
        if (!weaver) {
            // console.log('doesnt works?');
            return res.status(404).json({
                error: "Email not found",
            });
        }
        else {
            // console.log('works?');
            console.log(weaver);
            res.send(weaver);
            return weaver;
        }
    });
});

module.exports = router;

