import React from 'react'
import { useState } from "react";
import { Link } from 'react-router-dom'
import axios from "axios";
// import { useNavigate } from "react-router-dom";

import '../../App.css'

// const [email, setEmail] = useState("");
// const [password, setPassword] = useState("");

// const onChangeEmail = (event) => {
//     setEmail(event.target.value);
// };

// const onChangePassword = (event) => {
//     setPassword(event.target.value);
// };

// const navigate = useNavigate();

const onSubmit = (event) => {
    event.preventDefault();

    const newUser = {
        email: document.getElementById("email").value,
        password: document.getElementById("password").value,
    };
    // navigate("./Vendor")

    // alert(newUser.email);

    axios
        .post("http://localhost:5000/weaver/login", newUser)
        .then((response) => {
            //alert("Found vendor\t" + response.data.manager_name);
            alert("succesfull!!!");
            // sessionStorage.setItem("id", response.data._id);
            // sessionStorage.setItem("type", flag);
            // navigate("/Vendor");
            // navigate("/weaver_profile");
            sessionStorage.setItem("id",response.data._id);
            window.location.replace('/weaver_profile');
            //console.log(response.data);
        })
        .catch((err) => {
            alert(err.response.data);
        });


    // resetInputs();
};


export default function SignInPage() {
    return (
        <div className="text-center m-5-auto">
            <h2>Malkha Inventory Management Portal <br></br> Sign In</h2>
            <form action="/home">
                <p>
                    <label>Username or email address</label><br />
                    <input type="text" id="email" name="first_name" required />
                </p>
                <p>
                    <label>Password</label>
                    {/* <Link to="/forget-password"><label className="right-label">Forgot password?</label></Link> */}
                    <br />
                    <input type="password" id="password" name="password" required />
                </p>
                <p>
                    <button id="sub_btn" type="submit" onClick={onSubmit}>Login</button>
                </p>
            </form>
            <footer>
                {/* <p>First time? <Link to="/register">Create an account</Link>.</p> */}
                <p><Link to="/">Back to Homepage</Link>.</p>
            </footer>
        </div>
    )
}