import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import Menu from '@mui/material/Menu';
import MenuIcon from '@mui/icons-material/Menu';
import Container from '@mui/material/Container';
import Button from '@mui/material/Button';
import MenuItem from '@mui/material/MenuItem';
import {Link} from 'react-router-dom'


const ResponsiveAppBar = () => {
  const [anchorElNav, setAnchorElNav] = React.useState(null);

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    // console.log(anchorElNav);
    setAnchorElNav(null);
  };

  return (
    <AppBar position="static">
      <Container maxWidth="xl">
        <Toolbar disableGutters>
          
          {/* This one is the LOGO when page is in full screen */}
          <Typography
            variant="h6"
            noWrap
            component="div"
            style={{flexGrow:0.5}}
            sx={{ mr: 2, display: { xs: 'none', md: 'flex' } }}
          >
            Malkha Inventory 
          </Typography>


          {/* This shows that menu icon (3 lines) when page shrinks and what is shown in the menu*/}
          <Box sx={{ flexGrow: 1, display: { xs: 'flex', md: 'none' } }}>
            <IconButton
              size="large"
              aria-label="account of current user"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              onClick={handleOpenNavMenu}
              color="inherit"
            >
              <MenuIcon />
            </IconButton>
            <Menu
              id="menu-appbar"
              anchorEl={anchorElNav}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'left',
              }}
              keepMounted
              transformOrigin={{
                vertical: 'top',
                horizontal: 'left',
              }}
              open={Boolean(anchorElNav)}
              onClose={handleCloseNavMenu}
              sx={{
                display: { xs: 'block', md: 'none' },
              }}
            >
          
              <MenuItem
                onClick={handleCloseNavMenu}
                component={Link} to='/weaver_profile'
              >
                <Typography textAlign="center">Profile</Typography>
              </MenuItem>

              {/* <MenuItem
                onClick={handleCloseNavMenu}
              >
                <Typography textAlign="center">Favourites</Typography>
              </MenuItem> */}
             
              {/* <MenuItem
                onClick={handleCloseNavMenu}
                component={Link} to='/buyer/wallet'
              >
                <Typography textAlign="center">Wallet</Typography>
              </MenuItem> */}

              {/* <MenuItem
                onClick={handleCloseNavMenu}
                component={Link} to='/buyer/profile'
              >
                <Typography textAlign="center">Profile</Typography>
              </MenuItem> */}
              
              <MenuItem
                onClick={() => {sessionStorage.clear()}}
                component={Link} to='/'
              >
                <Typography textAlign="center">Logout</Typography>
              </MenuItem>

            </Menu>
          </Box>

          {/* This is Logo displayed if page shrink */}
          <Typography
            variant="h6"
            noWrap
            component="div"
            sx={{ flexGrow: 1, display: { xs: 'flex', md: 'none' } }}
          >
            Malkha Inventory
          </Typography>

          <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' } }}>
    
              <Button
                onClick={handleCloseNavMenu}
                component={Link} to='/weaver_profile'
                sx={{ my: 2, color: 'white', display: 'block' }}
              >
                Profile
              </Button>
             
              {/* <Button
                onClick={handleCloseNavMenu}
                sx={{ my: 2, color: 'white', display: 'block' }}
              >
                Favourites
              </Button> */}

              {/* <Button
                // key= 'wallet'
                onClick={handleCloseNavMenu}
                component={Link} to='/buyer/wallet'
                sx={{ my: 2, color: 'white', display: 'block' }}
              >
                Wallet
              </Button> */}

              {/* <Button
                onClick={handleCloseNavMenu}
                component={Link} to='/buyer/profile'
                sx={{ my: 2, color: 'white', display: 'block' }}
              >
                Profile
              </Button> */}

              <Button
                onClick={() => {sessionStorage.clear()}}
                component={Link} to='/'
                sx={{ my: 2, color: 'white', display: 'block' }}
              >
                Logout
              </Button>
          </Box>
            </Toolbar>
      </Container>
    </AppBar>
  );
};
export default ResponsiveAppBar;
